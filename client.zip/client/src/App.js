import React, { useState } from 'react';
import { Route, Routes } from 'react-router-dom'
import { AirContext } from './context/AirContext';
import Layout from './Layout';
import Home from './pages/Home';
import Jewelry from './pages/Jewelry'
import Watch from './pages/Watch';
import Man from './pages/Man'
import Gift from './pages/Gift'
import Store from './pages/Store'
import ItemDetail from './pages/ItemDetail';
import Login from './pages/Login'
import Join from './pages/Join'
import Cart from './pages/Cart';
import BoardList from './pages/BoardList'
import BoardWrite from './pages/BoardWrite'
import BoardView from './pages/BoardView'
import BoardModify from './pages/BoardModify'
import items from './assets/items'
import { HashRouter as BrowserRouter } from 'react-router-dom';

const App = () => {

  const [active, setActive] = useState(0)
  const [loging, setLoging] = useState(sessionStorage.getItem('id'))

  return (
    <AirContext.Provider value={{ active, setActive, loging, setLoging }}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="/jewelry" element={<Jewelry />} />
            <Route path="/watch" element={<Watch />} />
            <Route path="/man" element={<Man />} />
            <Route path="/gift" element={<Gift />} />
            <Route path="/store" element={<Store />} />
            <Route path="/itemdetail/:pid" element={<ItemDetail items={items} />} />
            <Route path="/login" element={<Login />} />
            <Route path="/join" element={<Join />} />
            <Route path='/cart' element={<Cart />} />
            <Route path="/board/list/:boardName" element={<BoardList />} />
            <Route path="/board/write/:boardName" element={<BoardWrite />} />
            <Route path="/board/view" element={<BoardView />} />
            <Route path="/board/modify" element={<BoardModify />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AirContext.Provider>
  );
};

export default App;