// localStorage에서 카트 항목을 저장하고 검색하는 코드가 포함된 업데이트된 Redux 파일
import { configureStore, createSlice } from "@reduxjs/toolkit"

const cart = createSlice({
  name: 'cart',
  initialState: getInitialCart(), // 저장된 카트 항목으로 초기화
  
  reducers: {
    addCount(state, action) {
      const index = state.findIndex((item) => item.id === action.payload);
      if (index !== -1) {
        state[index].quantity++;
      }
    },
    subCount(state, action) {
      const index = state.findIndex((item) => item.id === action.payload);
      if (index !== -1 && state[index].quantity > 1) {
        state[index].quantity--;
      }
    },
    deleteItems(state, action) {
      const itemIds = action.payload;
      return state.filter((item) => !itemIds.includes(item.id));
    },
    addItems(state, action) {
      const index = state.findIndex((item) => item.id === action.payload.id);
      if (index !== -1) {
        state[index].quantity++;
        state[index].image = action.payload.image;
      } else {
        state.push(action.payload);
      }
    },
    toggleItemSelection(state, action) {
      const itemId = action.payload;
      const item = state.find((item) => item.id === itemId);
      if (item) {
        item.selected = !item.selected;
      }
    },
    toggleAllItems(state) {
      const selectedItemsExist = state.some((item) => item.selected);
      state.forEach((item) => {
        item.selected = !selectedItemsExist;
      });
    },
  },
})

const selectedItems = createSlice({
  name: 'selectedItems',
  initialState: [],
  reducers: {
    setSelectedItems(state, action) {
      return action.payload;
    },
  },
});

const userSlice = createSlice({
  name: "user",
  initialState: {
    name: "",
    id: "",
    isLoading: false, // optional
    isLogin: null,
  },
  reducers: {
    // login 성공 시
    loginUser: (state, action) => {
      // name, id에 API 값 받아오기
      state.name = action.payload.name;
      state.id = action.payload.id;
      state.isLogin = true; // 로그인 상태를 true로 설정

    },
    // login 실패 시
    clearUser: (state) => {
      // name, id 값을 비워줌.
      state.name = "";
      state.id = "";
      state.isLogin = false; // 로그인 상태를 false로 설정
    },
    setIsLogin: (state, action) => {
      state.isLogin = action.payload;
    },
  },
});

//값을 변경할건데 기본값과 변할값이 들어가는게 reducers이다.

// localStorage에 저장된 카트 항목이 있는지 확인하고 해당 값을 초기 상태로 반환, 저장된 항목이 없을 경우 빈 배열을 반환
function getInitialCart() {
  const savedCart = localStorage.getItem('cart');
  return savedCart ? JSON.parse(savedCart) : [];
}

const store = configureStore({
  reducer: {
    cart: cart.reducer,
    selectedItems: selectedItems.reducer,
    user: userSlice.reducer,
  },
});

// 카트 상태의 변경을 감지하고 업데이트된 카트 항목을 localStorage에 저장하기 위해 사용
store.subscribe(() => {
  const cartItems = store.getState().cart;
  localStorage.setItem('cart', JSON.stringify(cartItems));
});

export const { addCount, subCount, deleteItems, addItems, toggleItemSelection, toggleAllItems } = cart.actions
//값을 만들었으면 내보내줘야하는데 리덕스의 기본은 import 와 export이다.

export const { setSelectedItems } = selectedItems.actions;

export const { loginUser, clearUser, setIsLogin } = userSlice.actions;

export default store;
