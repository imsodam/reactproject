import React from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { FaYoutube, FaFacebook, FaPinterest, FaInstagram } from 'react-icons/fa';
import { SiKakaotalk } from 'react-icons/si'

const FooterBlock = styled.footer`
    background: #f2f2f2;
    padding: 50px 0;
    margin-top: 50px;
    

    .row {
        display: flex;

        .ft {
            width: 33.33%;

            h3 {
                margin-bottom : 20px;
            }

            li {
                line-height: 2;
                text-index: -9999px;

                &:hover {
                    color: #999;
                }
            }
        }


        .footer03 {
            display: flex;
            font-size: 30px;

            ul {
                display: flex;
                flex-direction: row;
            
                li { margin-right: 15px; }
            }
        }
    }


`
const Footer = () => {
    return (
        <FooterBlock>
            <div className="row">
                <div className='ft footer01'>
                    <ul className='footer01_txt'>
                        <h3>Customer</h3>
                        <li><Link to=''>Request</Link></li>
                        <li><Link to=''>Q&A</Link></li>
                        <li><Link to=''>Reservation</Link></li>
                        <li><Link to=''>Product Care & Repair</Link></li>
                    </ul>
                </div>
                <div className='ft footer02'>
                    <ul className='footer02_txt'>
                        <h3>Our Company</h3>
                        <li><Link to=''>World of Tiffany</Link></li>
                        <li><Link to=''>Sustainability</Link></li>
                        <li><Link to=''>Policy</Link></li>
                        <li><Link to=''>Site Index</Link></li>
                    </ul>
                </div>
                <div className='ft footer03'>
                    <h3 className="blind">SNS</h3>
                    <ul className='footer03_txt'>
                        <li><Link to="https://www.youtube.com/OfficialTiffanyAndCo" target="_blank"><FaYoutube /></Link></li>
                        <li><Link to="https://www.facebook.com/Tiffany" target="_blank"><FaFacebook /></Link></li>
                        <li><Link to="https://www.pinterest.co.kr/tiffanyandco/" target="_blank"><FaPinterest /></Link></li>
                        <li><Link to="https://www.instagram.com/tiffanyandco/" target="_blank"><FaInstagram /></Link></li>
                        <li><Link to="https://pf.kakao.com/_xlieQj" target="_blank"><SiKakaotalk /></Link></li>
                    </ul>
                </div>
            </div>
        </FooterBlock>
    )

}

export default Footer