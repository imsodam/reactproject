import React, { useContext, useState, useEffect, useMemo } from 'react';
import Select from 'react-select';
import styled from 'styled-components'
import items from '../assets/items';
import Item from '../components/Item'
import { AirContext } from '../context/AirContext'

const Menu = styled.div`
        
        position: relative;

        .common_img {
            img {
                height: 70vh;
            }
        }
        
        .jewelry_menu {
            display: flex;
            justify-content: center;

            .btn_menu {
                display: flex;
                align-content: center;         
                border-radius: 4px;
        
                .menus {
                    width: 150px;
                    height: 60px;
                    line-height: 60px;
                    border: none;
                    background: #81d8d0;
                    color: #fff;
                    border-radius: 4px; 
                    cursor: pointer;
                    
                
                    &:nth-child(2){
                        margin: 0 10px;
                    }
                    &:nth-child(4){
                        margin: 0 10px;
                    }

                }
            }
        }

        .hidden_menu {
            display: none;
        }

        .jewelry_filter {
            position: absolute;
            right: 5%;
        }
    `
const Alldata = styled.div`
        width: 90%;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        margin: 100px auto 0;

        .alldata_box {
            text-align: center;
            width: 31%;
            margin-right: 35px; 
            margin-bottom: 35px;
        
            &:nth-child(3n) {
                margin-right: 0px;
            }
            
            img{
                border: 1px solid #fff;
                border-radius: 4px;

                &:hover {
                    border-color: #81d8d0;
                }
            }

        }

    `

const ItemList = ({ type }) => {

    const tabTit = useMemo(() => {
        const options = {
            jewelry: [
                { id: 0, part: items.jewelry.map(data => data), title: 'All' },
                { id: 1, part: items.jewelry.filter(data => data.part === 'ring'), title: 'Ring' },
                { id: 2, part: items.jewelry.filter(data => data.part === 'earring'), title: 'Earring' },
                { id: 3, part: items.jewelry.filter(data => data.part === 'bracelet'), title: 'Bracelet' }
            ],
            watch: items.watch.map(data => data),
            man: items.man.map(data => data),
            gift: items.gift.map(data => data)
        };

        return options[type] || [];
    }, [type]);


    const { active, setActive } = useContext(AirContext);
    const [selectedOption, setSelectedOption] = useState(null);
    const [sortedItems, setSortedItems] = useState([]);

    useEffect(() => {
        if (type === 'jewelry') {
            setSortedItems([...tabTit[active].part]);
        } else {
            setSortedItems([...tabTit]);
        }

    }, [type, active, tabTit]);

    const onSelect = (id) => {
        setActive(id);
    };

    const options = [
        { value: 'name', label: '상품명순' },
        { value: 'price', label: '가격순' },
    ];



    const handleOptionChange = (selectedOption) => {
        setSelectedOption(selectedOption);

        if (type === 'jewelry') {
            if (selectedOption && selectedOption.value === 'name') {
                const sortedItemsByName = [...tabTit[active].part].sort((a, b) => a.name.localeCompare(b.name));
                setSortedItems(sortedItemsByName);
            } else if (selectedOption && selectedOption.value === 'price') {
                const sortedItemsByPrice = [...tabTit[active].part].sort((a, b) => a.price - b.price);
                setSortedItems(sortedItemsByPrice);
            }
        } else {
            if (selectedOption && selectedOption.value === 'name') {
                const sortedItemsByName = [...tabTit].sort((a, b) => a.name.localeCompare(b.name));
                setSortedItems(sortedItemsByName);
            } else if (selectedOption && selectedOption.value === 'price') {
                const sortedItemsByPrice = [...tabTit].sort((a, b) => a.price - b.price);
                setSortedItems(sortedItemsByPrice);
            }
        }


    };



    return (
        <>
            <Menu>
                <div className="common_img">
                    {type === 'jewelry' ? <img src={'./images/jewelry.webp'} alt="주얼리이미지" /> : type === 'watch' ? <img src={'./images/watch.webp'} alt="시계이미지" /> : type === 'man' ? <img src={'./images/man.webp'} alt="남성용이미지" /> : <img src={'./images/gift.webp'} alt="기프트이미지" />}
                </div>


                {type === 'jewelry' && (
                    <div className='jewelry_menu'>
                        <div className="btn_menu">
                            {tabTit.map((data) => (
                                <div
                                    className="menus"
                                    key={data.id}
                                    onClick={() => onSelect(data.id)}
                                    style={{ background: active === data.id ? '#777' : '#81d8d0' }}
                                >
                                    {data.title}
                                </div>
                            ))}
                        </div>
                    </div>
                )}


                <div className="jewelry_filter">
                    <Select
                        onChange={handleOptionChange}
                        options={options}
                        placeholder="filter"
                        value={selectedOption}
                    />
                </div>
            </Menu>
            <Alldata>
                {sortedItems.map((data, index) => (
                    <Item iteminfo={data} key={index} />
                ))}
            </Alldata>
        </>
    );
};

export default ItemList;


