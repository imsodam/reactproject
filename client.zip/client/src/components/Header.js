import React, { useState, useContext, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { GiHamburgerMenu } from 'react-icons/gi'
import { FaUserCircle } from 'react-icons/fa'
import styled from 'styled-components'
import cn from 'classnames' // 변수를 클래스명으로 활용할때 해당 라이브러리 import
import { AirContext } from '../context/AirContext'

const HeaderBlock = styled.header`
    box-shadow: 0px 2px 2px #999;
    position: fixed;
    width: 100%;
    top: 0;
    left: 0;
    z-index: 9999;
    color: #fff;

    .row {
        display: flex;
        justify-content: space-between;
        align-items: center;

        nav {
            @media ${props => props.theme.tabletS}{
                display: none;
            }
            .depth1{
                display: flex;

            > li {
                margin: 0 20px;
                font-size: 20px;
                position: relative;
                padding: 10px 0;

                .depth2 {
                    display: none;
                    position: absolute;
                    top: 100%;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 150px;
                    background: #fff;
                    border: 1px solid #f2f2f2;
                    padding: 20px 0;
                    border-radius: 4px;
                    z-index: 9999;
                    color: #999;

                    li { padding: 5px 0; font-size: 16px; text-align: center;
                        &:hover { color: #81d8d0; }
                    }

                }
                &:hover > .depth2 {
                    display: block;
                }
            }
        }
    }

    .mobNav {
        position: relative;
        color: #000;
   

        .btn { 
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-radius: 50px;
            font-size: 20px;
            color: #fff;
            background: ${props => props.theme.btnBgColor};
          
            .ham {
                margin-right: 10px;
            }
        }

        .mobNavList {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            border: 1px solid #f2f2f2;
            width: 150px;
            padding: 10px 0;
            border-radius: 4px;
            background: #fff;
            z-index: 9999;
            margin-top: 10px;

            &.open { display: block }
            
            ul {
                li {
                    padding: 0 20px;
                    line-height: 30px;

                    &:nth-child(2) {
                        border-bottom: 1px solid #ddd;
                        padding-bottom: 10px;
                        margint-bottom: 10px;
                    }

                    &:hover { color: #81d8d0; }
                
                    .loggedInLink {
                        color: initial
                    }
                    
                    .joinLink {
                        &:hover { color: #81d8d0; }
                    }
                }
            }
        }
    }

}

`

const Header = () => {

    const [open, setOpen] = useState(false)
    const { setActive, loging, setLoging } = useContext(AirContext)
    const mobNavRef = useRef(null);
    const onSelect = (id) => {
        setActive(id)
    }

    const [scy, setScy] = useState(0)

    const onScroll = () => {
        setScy(window.scrollY)
    }

    useEffect(() => {
        window.addEventListener('scroll', onScroll)
        return () => window.removeEventListener('scroll', onScroll)
    }, [])

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (mobNavRef.current && !mobNavRef.current.contains(event.target)) {
                setOpen(false);
            }
        };

        document.addEventListener('mousedown', handleOutsideClick);
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick);
        };
    }, []);

    return (
        <HeaderBlock style={{ background: scy ? '#fff' : 'transparent', color: scy ? '#000' : '#666' }}>
            <div className='row'>
                <h1>
                    <Link to="/"><img src={'./images/logo.png'} alt="티파니로고" className="main_logo" /></Link>
                </h1>
                <nav>
                    <ul className='depth1'>
                        <li><Link to="/jewelry" onClick={() => onSelect(0)}>Jewelry</Link>
                            <ul className='depth2'>
                                <li><Link to='/jewelry' onClick={() => onSelect(1)}>Ring</Link></li>
                                <li><Link to='/jewelry' onClick={() => onSelect(2)}>Earring</Link></li>
                                <li><Link to='/jewelry' onClick={() => onSelect(3)}>Bracelet</Link></li>
                            </ul>
                        </li>
                        <li><Link to="/watch">Watch</Link></li>
                        <li><Link to="/man">Man</Link></li>
                        <li><Link to="/gift">Gift</Link></li>
                        <li><Link to="/store">Store</Link></li>
                    </ul>
                </nav>
                <div className='mobNav' ref={mobNavRef}>
                    <button className='btn' onClick={() => setOpen(!open)}>
                        <GiHamburgerMenu className="ham" />
                        <FaUserCircle />
                    </button>
                    <div className={cn('mobNavList', { open })}>
                        <ul>
                            <li>{loging ? <Link onClick={() => { sessionStorage.clear(); setLoging(''); window.location.reload(); }}>LogOut</Link> : <Link to="/login">Login</Link>}</li>
                            <li>{loging ? <Link className="loggedInLink">Hi! {loging}님</Link> : <Link to="/join" className="joinLink">Join</Link>}</li>
                            <li><Link to="/cart">Cart</Link></li>
                            <li><Link to="/board/list/qna">Q&A</Link></li>
                        </ul>
                    </div>
                </div>
            </div>
        </HeaderBlock>
    )
}

export default Header