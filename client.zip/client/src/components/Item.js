import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components'


const Material = styled.div`
    margin-top: 30px;
    color: #777;
`
const Name = styled.div`
    font-size: 20px;
    font-weight: 700;
    color: #333;
    margin: 20px 0;

    &:hover {
        color: #888;
    }
`

const Item = ({ iteminfo }) => {

    return (
        <Link to={`/itemdetail/${iteminfo.id}`} className="alldata_box">
            <img src={iteminfo.image} alt="상품사진" />
            <Material>{iteminfo.material}</Material>
            <Name>{iteminfo.name}</Name>
            <p>{iteminfo.price.toLocaleString()}</p>
        </Link>
    );
};

export default Item;