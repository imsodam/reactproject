import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'
import items from '../assets/items';
import Slider from 'react-slick'
import styled from 'styled-components'

const TiffanyChoice = styled.div`
    .choice {
        margin: 100px 200px;

        h1 {font-size: 25px; margin: 50px 0; color: #333;} 
        .choice_box {
            margin: 0 auto;
            text-align: center;
           
            img {
                border: 1px solid #ddd;
                border-radius: 4px;
                display: inline-block;

                &:hover {
                    border-color: #81d8d0;
                }
            }
            
        }

        .slick-dots {
            position: absolute; 
            bottom: -60px; 
            left:50%; 
            transform:translate(-50%);

            li { 
                display: inline-block; 
                padding: 0 5px; 
                button { 
                    width: 10px; 
                    height: 10px; 
                    border-radius: 50%; 
                    background: #f2f2f2; 
                    text-indent: -9999px; 
                    overflow:hidden 
                }
                 &.slick-active { button { background: ${props => props.theme.btnBgColor} } }
               }
        }
    }
`

const Name = styled.p`
    font-size: 20px;
    font-weight: bold;
    color: #333;
    margin: 20px 0;
`
const SliderComponent = () => {


    const [nine, setNine] = useState([])


    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 3,
        autoplay: true,
        autoplaySpeed: 4000,
        prevArrow: null,
        nextArrow: null,
        arrows: false,

    };

    useEffect(() => {
        setNine(items.jewelry.filter((data) => data.recommand === true))
    }, [])

    return (
        <TiffanyChoice>
            <div className="choice">
                <h1>Tiffany's Choice</h1>
                <Slider {...settings}>
                    {
                        nine.map((data, index) => (
                            <div className="choice_box" key={index}>
                                <Link to={`/itemdetail/${data.id}`}>
                                    <img src={data.image} alt="상품이미지" style={{ width: 420 }} />
                                    <Name>{data.name}</Name>
                                    <p className='material'>{data.material}</p>
                                    <p>{data.price.toLocaleString()}</p>
                                </Link>
                            </div>
                        ))
                    }
                </Slider>
            </div >
        </TiffanyChoice >
    );
};

export default SliderComponent;