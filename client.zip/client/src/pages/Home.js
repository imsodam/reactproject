import React, { useEffect, useContext } from 'react';
import styled from 'styled-components'
import Slider from 'react-slick'           // npm i react-slick
import 'slick-carousel/slick/slick.css'    // npm i -D slick-carousel 
import { IoIosArrowDropleftCircle, IoIosArrowDroprightCircle } from 'react-icons/io';
import AOS from 'aos'
import 'aos/dist/aos.css'
import { Link } from 'react-router-dom'
import { AirContext } from '../context/AirContext'
import MultipleItems from '../components/SliderComponent'

const HomeSectionBlock = styled.div`

    // article1
    .article1 { position:relative;
        .slide {
            height:52vw; position:relative; 
            background-size:cover;
            background-position:center;
            &.slide1 { background-image:url('images/img1.webp') };
            &.slide2 { background-image:url('images/img2.webp') };
            &.slide3 { background-image:url('images/img3.png') };
            .text {
                position:absolute; top:50%; left:50%;
                transform:translate(-50%, -50%);
                font-size:30px; color:#000; 
                text-align:center;
                button { padding:10px; background:#A2B5BB; color:#fff; border-radius:10px; margin-top: 20px; }
            }
        }

        .slick-arrow {
            position:absolute; top:50%; transform:translateY(-50%); font-size:50px; color:#fff; 
            &.slick-prev { left:50px; z-index:9999 }
            &.slick-next { right:50px } 
         }
   
        .slick-dots { 
            position: absolute; 
            bottom: 30px; 
            left:50%; 
            transform:translate(-50%);
           li { 
            display: inline-block; 
            padding: 0 5px; 
            button { width:30px; height:30px; border-radius:50%; background:#fff; text-indent:-9999px; overflow:hidden }
             &.slick-active { button { background: ${props => props.theme.btnBgColor} } }
           }
         }
    }

    // article2
    .article2 { height:40vw; margin:100px;
        h2 { font-size: 25px; margin:50px 0; color: #333;}
        ul { display: flex; justify-content:space-between; 
          li { width:32%; color: #666; 
            img { height: 600px; border-radius: 4px; margin-bottom: 20px; transition: all .3s ease-in}
            img:hover { opacity: 0.4}
            p { font-size: 20px; color: #333; text-align:center;}
              } 
        }
    }

    // article3
    .article3 {
        margin: 100px 0; background: #999;
        .article3_inner { 
            background:url('images/article3.webp') 50% 40% no-repeat;  
            background-attachment: fixed;
            background-size: cover;
            padding: 10%;
            opacity: 0.7;

            .article3_tit {
                font-size: 25px;
            }

            p{
                margin: 50px 0 20px;
                line-height: 2;
                font-size: 18px;
            }
        }

    }

`

const Home = () => {

    const settings = {
        dots: true,
        autoplay: true,
        autoplaySpeed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow: <IoIosArrowDropleftCircle />,
        nextArrow: <IoIosArrowDroprightCircle />
    }

    const { setActive } = useContext(AirContext)

    const onSelect = (id) => {
        setActive(id)
    }

    useEffect(() => {
        AOS.init({ duration: 500 })
    }, [])

    return (
        <HomeSectionBlock>
            <div className="article1">
                <Slider {...settings}>
                    <div className="slide slide1">
                        <div className="text">
                            <p>나만의 방식으로 사랑하세요</p>
                            <button>Love & Engagement 자세히보기</button>
                        </div>
                    </div>
                    <div className="slide slide2">
                        <div className="text">
                            <p>No rules. All welcome.</p>
                            <button>티파니 락 자세히보기</button>
                        </div>
                    </div>
                    <div className="slide slide3">
                        <div className="text">
                            <p>티파니 셀렉션에서 완벽한 선물을 찾아보세요</p>
                            <button>기프트 자세히보기</button>
                        </div>
                    </div>
                </Slider>
            </div>
            <div className="article2">
                <h2 data-aos="fade-up" data-aos-delay="500">나를 표현하다</h2>
                <ul>
                    <li data-aos="fade-up" data-aos-delay="600">
                        <Link to='/jewelry' onClick={() => onSelect(1)}><img src="./images/ring.webp" alt="" /></Link>
                        <p>Ring</p>
                    </li>
                    <li data-aos="fade-up" data-aos-delay="700">
                        <Link to='/jewelry' onClick={() => onSelect(2)}><img src="./images/earring.webp" alt="" /></Link>
                        <p>Earring</p>
                    </li>
                    <li data-aos="fade-up" data-aos-delay="800">
                        <Link to='/jewelry' onClick={() => onSelect(3)}><img src="./images/bracelet.webp" alt="" /></Link>
                        <p>Bracelet</p>
                    </li>
                </ul>
            </div>
            <div className='article3'>
                <div className='article3_inner'>
                    <h3 className='article3_tit'>Diamond Jewelry</h3>
                    <p>When diamonds are the question,
                        Tiffany is always the answer. Defined by
                        high standards and expert craftsmanship,<br />
                        our designs are known as the best for a reason.
                    </p>
                    <span><Link to='/store'>View More &gt;</Link></span>
                </div>
            </div>
            <div className="article4">
                <MultipleItems />
            </div>
        </HomeSectionBlock>
    );
};

export default Home;