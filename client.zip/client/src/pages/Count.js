import styled from 'styled-components'
import { AiOutlinePlus, AiOutlineMinus} from 'react-icons/ai'

const CountButton = styled.button`
  width: 20px;
  height: 20px;
  font-size: 18px;
  background-color: white;
  margin: 0 20px;
  border: none;
`

const Count = (props) => {
    return (
        <span>
            <CountButton onClick={props.minusClick}>
                <AiOutlineMinus />
            </CountButton>
            <span>{props.count}</span>
            <CountButton onClick={props.plusClick}>
                <AiOutlinePlus />
            </CountButton>
        </span>
    )
}

export default Count