import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom'
import { addCount, subCount, deleteItems, toggleAllItems, toggleItemSelection, setSelectedItems, setIsLogin } from '../assets/store';
import { AiOutlinePlus, AiOutlineMinus } from 'react-icons/ai';
import { FaTrashRestore } from 'react-icons/fa';
import './Style/cart.css';

const Cart = () => {
  const cartItems = useSelector((state) => state.cart);
  console.log(cartItems)
  const selectedItems = useSelector((state) => state.selectedItems);
  const isLogin = useSelector((state) => state.user.isLogin);

  const dispatch = useDispatch();
  const navigate = useNavigate();



  const updateTotal = (item) => {
    return (item.price * item.quantity).toLocaleString();
  };

  const handleCheckboxChange = (itemId) => {
    dispatch(toggleItemSelection(itemId));

    const item = cartItems.find((item) => item.id === itemId);
    const updatedSelectedItems = item.selected
      ? selectedItems.filter((selectedItem) => selectedItem.id !== itemId)
      : [...selectedItems, item];

    dispatch(setSelectedItems(updatedSelectedItems));
  };

  const handleToggleAllItems = () => {
    dispatch(toggleAllItems());
    if (selectedItems.length !== cartItems.length) {
      dispatch(setSelectedItems(cartItems));
    } else {
      dispatch(setSelectedItems([]));
    }
  };

  useEffect(() => {
    dispatch(setSelectedItems([]));
  }, [dispatch]);

  const handleDeleteSelectedItems = () => {
    const selectedIds = selectedItems.map((item) => item.id);
    dispatch(deleteItems(selectedIds));
    dispatch(setSelectedItems([]));
  };

  const calculateTotalAmount = () => {
    return cartItems.reduce((total, item) => {
      if (selectedItems.some((selectedItem) => selectedItem.id === item.id)) {
        return total + item.price * item.quantity;
      }
      return total;
    }, 0).toLocaleString();
  };

  const handleLogin = () => {

    const user = { id: '사용자ID', name: '사용자이름' };
    sessionStorage.setItem('user', JSON.stringify(user));

    dispatch(setIsLogin(true));
  };

  const handlePayment = () => {
    if (!isLogin) {
      handleLogin();
      alert('로그인이 필요합니다. 로그인하세요.');
      navigate('/login');
    } else {
      handleLogin();
      alert('결제페이지로 이동');
    };
  }

  return (
    <section>
      <h1>CART</h1>
      <div className='allbutton'>
        <button onClick={handleToggleAllItems}>
          전체선택
        </button>
        <button onClick={handleDeleteSelectedItems} disabled={selectedItems.length === 0}>
          선택삭제
        </button>
      </div>
      <table>
        <thead>
          <tr>
            <th>
              <input
                type="checkbox"
                checked={selectedItems.length === cartItems.length && cartItems.length > 0}
                onChange={handleToggleAllItems}
              />
            </th>
            <th>상품사진</th>
            <th>상품명</th>
            <th>가격</th>
            <th>갯수</th>
            <th>수량</th>
            <th>총 금액</th>
            <th>삭제</th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map((item) => (
            <tr key={item.id}>
              <td>
                <input
                  type="checkbox"
                  checked={selectedItems.some((selectedItem) => selectedItem.id === item.id)}
                  onChange={() => handleCheckboxChange(item.id)}
                />
              </td>
              <td>
                <Link to={`/itemdetail/${item.id}`}><div className='itemimage'><img src={item.image} alt="상품 사진" /></div></Link>
              </td>
              <td><Link to={`/itemdetail/${item.id}`}>{item.name}</Link></td>
              <td>￦ {item.price.toLocaleString()}</td>
              <td>{item.quantity}</td>
              <td>
                <button
                  onClick={() => {
                    dispatch(addCount(item.id));
                  }}
                  style={{ background: 'transparent', fontSize: '20px', marginRight: 10 }}
                >
                  <AiOutlinePlus />
                </button>
                <button
                  onClick={() => {
                    dispatch(subCount(item.id));
                  }}
                  style={{ background: 'transparent', fontSize: '20px' }}
                >
                  <AiOutlineMinus />
                </button>
              </td>
              <td>￦ {updateTotal(item)}</td>
              <td>
                <button
                  onClick={() => {
                    dispatch(deleteItems([item.id]));
                  }}
                  style={{ background: 'transparent', fontSize: '20px' }}
                >
                  <FaTrashRestore />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan="5">최종금액</td>
            <td colSpan="2">￦ {calculateTotalAmount()}</td>

            <button onClick={handlePayment} disabled={selectedItems.length === 0}>
              결제하기
            </button>
          </tr>
        </tfoot>
      </table>
    </section >
  );
};

export default Cart;
