import React, { useState, useRef, useEffect } from 'react';
import styled from 'styled-components'
import MapContainer from '../components/MapContainer'
import { AiOutlineSearch } from 'react-icons/ai'

const StoreBlock = styled.div`
    border-top:87px solid transparent;
    .row {
       margin: 150px auto ;
        form {
            display: flex; 
            margin-bottom: 20px;

            input { 
                padding: 10px; 
                width: 30%; 
                border-radius: 5px 0px 0px 5px; 
                outline: none; 
                border: 2px solid ${props => (props.formClicked ? '#81d8d0' : '#666')};
            }
            button { 
                padding: 10px 10px 0 10px; 
                border-radius: 0px 5px 5px 0px; 
                background: ${props => (props.formClicked ? '#81d8d0' : '#666')}; 
                color: #fff; 
                border:1px solid ${props => (props.formClicked ? '#81d8d0' : '#666')}; 
                font-size: 20px; }
            }
    }
`

const Store = () => {

    const [inputText, setInputText] = useState('현대백화점 무역센터점')
    const [place, setPlace] = useState('현대백화점 무역센터점')
    const inputBox = useRef()
    const [formClicked, setFormClicked] = useState(false);


    const onSubmit = (e) => {
        e.preventDefault()
        setPlace(inputText)
        // setInputText('')
        inputBox.current.focus()
    }

    const onChange = (e) => {
        setInputText(e.target.value)
        // console.log(e)
    }

    useEffect(() => {
        inputBox.current.focus()
    }, [])

    const handleClickForm = () => {
        setFormClicked(true);
    };
    return (
        <StoreBlock formClicked={formClicked}>
            <div className="row">
                <form onClick={handleClickForm} onSubmit={onSubmit}>
                    <input ref={inputBox} type="text" placeholder="장소입력" onChange={onChange} value={inputText} />
                    <button type="submit"><AiOutlineSearch /></button>
                </form>
                <MapContainer searchPlace={place} />
            </div>
        </StoreBlock>
    );
};

export default Store;
