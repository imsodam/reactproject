import React from 'react';
import styled from 'styled-components'
// import Select from 'react-select';
// import items from '../assets/items';
import ItemList from '../components/ItemList';



const Jewelrymenu = styled.div`
    
    position: relative;

    .jewelry_img {
        img {
            height: 60vh;
        }
    }
    
    .jewelry_menu {
        .btn_menu {
            margin: 100px 0;
            text-align: center;
    
            button {
                width: 150px;
                height: 60px;
                line-height: 60px;
                border: none;
                background: #81d8d0;
                color: #fff;
                border-radius: 4px; 
                
            
                &:nth-child(2){
                    margin: 0 10px;
                }
                &:nth-child(4){
                    margin: 0 10px;
                }
                &:hover {
                    background: #777;
                    color: #81d8d0;
                }
            }
        }
    }

    .jewelry_filter {
        position: absolute;
        right:5%; 
    }


    
`

const Jewelry = () => {
    return (
        <Jewelrymenu>
            <ItemList type='jewelry' />
        </Jewelrymenu>
    );
};

export default Jewelry;