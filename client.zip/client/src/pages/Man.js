import React from 'react';
import ItemList from '../components/ItemList';
import styled from 'styled-components'

const Menu = styled.div`
    
position: relative;
.common_img {
    img {
        height: 70vh;
        margin-bottom: 100px;
    }
}

.jewelry_filter {
    position: absolute;
    right: 5%;
    bottom: -10%
}
`

const Man = () => {
    return (
        <>
            <Menu>
                <ItemList type='man' />
            </Menu>
        </>
    );
};

export default Man;