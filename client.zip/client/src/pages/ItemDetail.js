import React, { useState } from 'react';
import styled from 'styled-components'
import { useParams, useNavigate } from "react-router-dom"
import { useDispatch } from 'react-redux'
import { addItems } from '../assets/store' //상태관리하는 리덕스파일
import Count from './Count'
import items from '../assets/items.js';
import { AiFillShopping, AiFillHeart } from 'react-icons/ai'
import './Style/itemdetail.css'


const Name = styled.p`
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 20px;
`

const Price = styled.p`
  font-size: 20px;
  font-weight: bold;
  text-align: right;
  padding: 30px 0 20px;
    
`

const Total = styled.p`
  text-align: right;
  font-weight: bold;
  margin-top: 20px;
`

const Button = styled.button`
  width: 60px;
  height: 60px;
  border: 1px solid #ccc;
  background: #fff;
  font-size: 20px;
  transition: all .3s;

  &:hover {
    background: #f2f2f2;
  }
`

const GetButton = styled(Button)`
  width: 260px;
  border: none;
  background: black;
  color: #fff;
  margin-left: 10px;
  transition: all .3s;

  &:hover {
    background: #666;
  }
`



const ItemDetail = () => {

    const { pid } = useParams()
    const allItems = items.jewelry.concat(items.jewelry, items.watch, items.man, items.gift);
    const iteminfo = allItems.find((data) => data.id === pid)

    const dispatch = useDispatch()
    const navigate = useNavigate()

    const [count, setCount] = useState(1)

    if (!iteminfo) {
        return <div>Item not found</div>;
    }

    const handleGetButton = () => {
        const isLoggedIn = false;

        if (isLoggedIn) {
            dispatch(
                addItems({ id: iteminfo.id, name: iteminfo.name, quantity: count, price: iteminfo.price * count, image: iteminfo.image })
            );
            alert('장바구니에 추가되었습니다.');
            navigate('/cart');
        } else {
            alert('로그인하세요');
            navigate('/login');
        }
    };

    return (
        <div className='item-detail'>
            <div className="detail_box">
                <div className='innerbox'>
                    <img src={iteminfo.image} alt="" />
                    <img src={iteminfo.detailimage2} alt="" />
                    <img src={iteminfo.detailimage3} alt="" />
                    <img src={iteminfo.detailimage4} alt="" />
                </div>

                <div className="detail_info">
                    <Name>{iteminfo.name}</Name>
                    <p>{iteminfo.material}</p>
                    <hr />
                    <Price>
                        ￦ {iteminfo.price.toLocaleString()}
                        <span>
                            <Count
                                count={count}
                                plusClick={() => setCount((prev) => prev + 1)}
                                minusClick={() => {
                                    if (count > 1) {
                                        setCount((prev) => prev - 1);
                                    } else {
                                        setCount(1);
                                    }
                                }}
                            />
                        </span>
                    </Price>
                    <hr />
                    <Total>총 합계 금액 ￦ {(iteminfo.price * count).toLocaleString()}</Total>
                    <Button style={{ marginRight: 10 }}>
                        <AiFillHeart />
                    </Button>
                    <Button onClick={() => {
                        dispatch(addItems({ id: iteminfo.id, name: iteminfo.name, quantity: count, price: iteminfo.price * count, image: iteminfo.image }))
                        alert('장바구니에 추가되었습니다.')
                        navigate('/cart')
                    }}><AiFillShopping />
                    </Button>
                    <GetButton onClick={handleGetButton}>
                        바로구매
                    </GetButton>
                </div>
            </div>
        </div>
    );
};

export default ItemDetail;
