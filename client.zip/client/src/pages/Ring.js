import React, { useState, useEffect } from 'react';
import items from '../assets/items';
import styled from 'styled-components'
import { Link } from 'react-router-dom'

const RingData = styled.div`
    width: 90%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 200px auto 0;

    .alldata_box {
        text-align: center;
        width: 31%;
        margin-right: 35px; 
        margin-bottom: 35px;

        &:nth-child(3n) {
            margin-right: 0px;
        }
    
        img{
            border: 1px solid #fff;
            border-radius: 4px;

            &:hover {
                border-color: #81d8d0;
            }
        }

    }
`
const Material = styled.div`
    padding-top: 10px;
`
const Name = styled.div`
    font-size: 20px;
    color: #333;
    margin: 20px 0;
`
const Ring = () => {


    const [onlyring, setOnlyring] = useState([])

    useEffect(() => {
        setOnlyring(items.filter((data) => data.part === 'ring'))
    }, [])

    return (
        <RingData>
            {
                onlyring.map((data, index) => {

                    return (
                        <div className="alldata_box">
                            <Link to={`/itemdetail/${index}`}>
                                <img src={data.image} alt="" />
                                <p>
                                    <Material>{data.material}</Material>
                                </p>
                                <Name>{data.name}</Name>
                                <p>{data.price.toLocaleString()}</p>
                            </Link>
                        </div>
                    )
                })
            }
        </RingData>
    );
};

export default Ring;